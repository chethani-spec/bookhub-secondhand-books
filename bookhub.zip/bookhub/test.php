<?php
echo "Test successful!";
?>